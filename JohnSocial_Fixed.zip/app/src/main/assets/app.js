const DB_NAME="JohnSocialDB", DB_VERSION=1, STORE="videos";
let users=JSON.parse(localStorage.getItem("users")||"[]");
let currentUser=localStorage.getItem("currentUser")||"";
let posts=JSON.parse(localStorage.getItem("posts")||"[]");
let notifications=JSON.parse(localStorage.getItem("notifications")||"[]");
let activeCommentPost=null, searchMode="users", videoUrls={};

function save(){localStorage.setItem("users",JSON.stringify(users));localStorage.setItem("posts",JSON.stringify(posts));localStorage.setItem("notifications",JSON.stringify(notifications));localStorage.setItem("currentUser",currentUser)}
function db(){return new Promise((resolve,reject)=>{const r=indexedDB.open(DB_NAME,DB_VERSION);r.onupgradeneeded=()=>{if(!r.result.objectStoreNames.contains(STORE))r.result.createObjectStore(STORE)};r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error)})}
async function putVideo(id,blob){const d=await db();return new Promise((res,rej)=>{const tx=d.transaction(STORE,"readwrite");tx.objectStore(STORE).put(blob,String(id));tx.oncomplete=()=>res();tx.onerror=()=>rej(tx.error)})}
async function getVideo(id){const d=await db();return new Promise((res,rej)=>{const tx=d.transaction(STORE,"readonly");const q=tx.objectStore(STORE).get(String(id));q.onsuccess=()=>res(q.result||null);q.onerror=()=>rej(q.error)})}
async function deleteVideo(id){try{const d=await db();const tx=d.transaction(STORE,"readwrite");tx.objectStore(STORE).delete(String(id))}catch(e){}}
function showSignup(){document.getElementById("loginForm").classList.add("hidden");document.getElementById("signupForm").classList.remove("hidden");msg("")}
function showLogin(){document.getElementById("signupForm").classList.add("hidden");document.getElementById("loginForm").classList.remove("hidden");msg("")}
function msg(t){document.getElementById("authMessage").textContent=t||""}
function validUsername(u){return /^[A-Za-z0-9_]{3,20}$/.test(u)}
function signup(){
 const u=document.getElementById("signupUsername").value.trim(),p=document.getElementById("signupPassword").value;
 if(!validUsername(u))return msg("Username must be 3–20 letters, numbers or _."); if(p.length<4)return msg("Password must be at least 4 characters.");
 if(users.some(x=>x.username.toLowerCase()===u.toLowerCase()))return msg("That username already exists.");
 users.push({username:u,password:p,following:[],followers:[]});currentUser=u;save();openApp()
}
function login(){
 const u=document.getElementById("loginUsername").value.trim(),p=document.getElementById("loginPassword").value;
 const found=users.find(x=>x.username.toLowerCase()===u.toLowerCase()&&x.password===p);
 if(found){currentUser=found.username;save();openApp()}else msg("Wrong username or password.")
}
function logout(){currentUser="";save();document.getElementById("appScreen").classList.add("hidden");document.getElementById("authScreen").classList.remove("hidden")}
function openApp(){document.getElementById("authScreen").classList.add("hidden");document.getElementById("appScreen").classList.remove("hidden");showPage("homePage");renderAll()}
function showPage(id){document.querySelectorAll(".page").forEach(x=>x.classList.add("hidden"));document.getElementById(id).classList.remove("hidden");if(id==="homePage")renderFeed();if(id==="profilePage")renderProfile();if(id==="notificationsPage")renderNotifications()}
function current(){return users.find(u=>u.username===currentUser)}
function user(name){return users.find(u=>u.username===name)}
function isFollowing(name){return !!current()?.following?.includes(name)}
function followUser(name){
 if(name===currentUser)return;
 const me=current(), target=user(name);if(!me||!target)return;
 me.following=me.following||[];target.followers=target.followers||[];
 if(me.following.includes(name)){me.following=me.following.filter(x=>x!==name);target.followers=target.followers.filter(x=>x!==currentUser)}
 else {me.following.push(name);if(!target.followers.includes(currentUser))target.followers.push(currentUser);addNotification(name,`${currentUser} followed you.`)}
 save();renderAll()
}
function addNotification(to,text){
 notifications.unshift({id:Date.now()+Math.random(),to,text,read:false,time:Date.now()});
 if(notifications.length>200)notifications.length=200
}
function notifyPostOwner(p,text){if(p.user!==currentUser)addNotification(p.user,text)}
async function uploadVideo(){
 const f=document.getElementById("videoFile").files[0],c=document.getElementById("videoCaption").value.trim(),filter=document.getElementById("videoFilter").value,m=document.getElementById("uploadMessage");
 if(!f)return m.textContent="Choose a video first.";
 if(!f.type.startsWith("video/"))return m.textContent="Please choose a video file.";
 m.textContent="Saving video...";
 const id=Date.now();try{await putVideo(id,f);posts.unshift({id,user:currentUser,caption:c,filter,likes:[],comments:[]});save();document.getElementById("videoFile").value="";document.getElementById("videoCaption").value="";m.textContent="Posted! 🎉";renderFeed();showPage("homePage")}catch(e){m.textContent="Could not save this video. Try a smaller file."}
}
function filterClass(f){return f==="none"?"":"filter-"+f}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
async function videoSrc(p){
 if(videoUrls[p.id])return videoUrls[p.id];
 try{const b=await getVideo(p.id);if(b){videoUrls[p.id]=URL.createObjectURL(b);return videoUrls[p.id]}}catch(e){}
 return ""
}
function postShell(p,src){
 const liked=p.likes.includes(currentUser),follow=p.user!==currentUser;
 return `<article class="post"><div class="post-header"><div class="small-avatar">${esc(p.user[0]?.toUpperCase()||"?")}</div><div class="user-block"><div class="username">${esc(p.user)}</div><div class="muted">${timeAgo(p.id)}</div></div>${follow?`<button class="follow ${isFollowing(p.user)?"following":""}" onclick="followUser('${esc(p.user)}')">${isFollowing(p.user)?"Following":"Follow"}</button>`:""}</div><div class="video-container">${src?`<video class="${filterClass(p.filter)}" src="${src}" controls playsinline preload="metadata"></video>`:`<div style="padding:50px;text-align:center;color:white">Video unavailable</div>`}</div><div class="post-body"><div class="caption">${esc(p.caption)}</div><div class="actions"><button class="${liked?"active":""}" onclick="toggleLike(${p.id})">♥ ${p.likes.length}</button><button onclick="openComments(${p.id})">💬 ${p.comments.length}</button><button onclick="sharePost(${p.id})">↗ Share</button></div></div></article>`
}
async function renderPosts(list,el){
 if(!list.length){el.innerHTML="<p class='muted'>No videos found yet.</p>";return}
 el.innerHTML=list.map(p=>postShell(p,"")).join("");
 await Promise.all(list.map(async p=>{const src=await videoSrc(p);const node=el.querySelector(`video[src=""]`);const vids=[...el.querySelectorAll("video")];const idx=list.indexOf(p);if(vids[idx]&&src)vids[idx].src=src}))
}
function renderFeed(){const el=document.getElementById("feed");let list=posts;if(current()?.following?.length)list=posts.filter(p=>p.user===currentUser||current().following.includes(p.user)||true);renderPosts(list,el)}
function toggleLike(id){const p=posts.find(x=>x.id===id);if(!p)return;const i=p.likes.indexOf(currentUser);if(i>=0)p.likes.splice(i,1);else{p.likes.push(currentUser);notifyPostOwner(p,`${currentUser} liked your video.`)}save();renderFeed();if(!document.getElementById("profilePage").classList.contains("hidden"))renderProfile()}
function openComments(id){activeCommentPost=id;document.getElementById("commentModal").classList.remove("hidden");renderComments()}
function closeComments(){document.getElementById("commentModal").classList.add("hidden");activeCommentPost=null}
function renderComments(){const p=posts.find(x=>x.id===activeCommentPost);document.getElementById("commentsList").innerHTML=p?.comments.length?p.comments.map(c=>`<div class="comment"><strong>${esc(c.user)}</strong>${esc(c.text)}</div>`).join(""):"<p class='muted'>No comments yet. Be the first!</p>"}
function addComment(){const input=document.getElementById("commentInput"),t=input.value.trim();if(!t||activeCommentPost==null)return;const p=posts.find(x=>x.id===activeCommentPost);p.comments.push({user:currentUser,text:t,time:Date.now()});input.value="";notifyPostOwner(p,`${currentUser} commented on your video.`);save();renderComments();renderFeed()}
function sharePost(id){const text="Check out this video on John Social!";if(navigator.share)navigator.share({title:"John Social",text}).catch(()=>{});else{navigator.clipboard?.writeText(text);alert("Share text copied!")}}
function setSearchMode(m){searchMode=m;document.getElementById("usersTab").classList.toggle("active",m==="users");document.getElementById("videosTab").classList.toggle("active",m==="videos");searchAll()}
function searchAll(){const q=document.getElementById("searchInput").value.trim().toLowerCase(),el=document.getElementById("searchResults");if(searchMode==="users"){const found=users.filter(u=>u.username.toLowerCase().includes(q));el.innerHTML=found.map(u=>`<div class="user-result"><div class="small-avatar">${esc(u.username[0].toUpperCase())}</div><div><strong>${esc(u.username)}</strong><div class="muted">${u.followers?.length||0} followers</div></div><div class="spacer"></div>${u.username!==currentUser?`<button class="follow ${isFollowing(u.username)?"following":""}" onclick="followUser('${esc(u.username)}')">${isFollowing(u.username)?"Following":"Follow"}</button>`:"<span class='muted'>You</span>"}</div>`).join("")||"<p class='muted'>No people found.</p>"}else{const found=posts.filter(p=>(p.caption+" "+p.user).toLowerCase().includes(q));renderPosts(found,el)}}
function renderProfile(){const me=current(),mine=posts.filter(p=>p.user===currentUser);document.getElementById("profileAvatar").textContent=currentUser[0]?.toUpperCase()||"J";document.getElementById("profileName").textContent=currentUser;document.getElementById("profileUsername").textContent="@"+currentUser;document.getElementById("profileFollowers").textContent=`${me?.followers?.length||0} followers • ${me?.following?.length||0} following`;document.getElementById("postCount").textContent=mine.length;document.getElementById("likeCount").textContent=mine.reduce((a,p)=>a+p.likes.length,0);document.getElementById("commentCount").textContent=mine.reduce((a,p)=>a+p.comments.length,0);renderPosts(mine,document.getElementById("profileVideos"))}
function renderNotifications(){const mine=notifications.filter(n=>n.to===currentUser);document.getElementById("notificationsList").innerHTML=mine.length?mine.map(n=>`<div class="notification ${n.read?"":"unread"}"><strong>${esc(n.text)}</strong><div class="muted">${timeAgo(n.time)}</div></div>`).join(""):"<p class='muted'>No notifications yet.</p>";mine.forEach(n=>n.read=true);save();updateBadge()}
function updateBadge(){const n=notifications.filter(x=>x.to===currentUser&&!x.read).length;document.getElementById("notifBadge").textContent=n?`(${n})`:""}
function timeAgo(t){const sec=Math.max(1,Math.floor((Date.now()-t)/1000));if(sec<60)return"just now";if(sec<3600)return Math.floor(sec/60)+"m ago";if(sec<86400)return Math.floor(sec/3600)+"h ago";return Math.floor(sec/86400)+"d ago"}
function renderAll(){renderFeed();renderProfile();updateBadge();if(!document.getElementById("searchPage").classList.contains("hidden"))searchAll()}
window.addEventListener("load",()=>{if(currentUser&&user(currentUser))openApp();else{currentUser="";save()}});
