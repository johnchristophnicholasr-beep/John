package com.example.chess;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.*;
import android.view.MotionEvent;
import android.view.View;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(new Board(this));
    }

    static class Board extends View {
        final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        final String[] pieces = {
            "♜","♞","♝","♛","♚","♝","♞","♜",
            "♟","♟","♟","♟","♟","♟","♟","♟",
            "","","","","","","","",
            "","","","","","","","",
            "","","","","","","","",
            "","","","","","","","",
            "♙","♙","♙","♙","♙","♙","♙","♙",
            "♖","♘","♗","♕","♔","♗","♘","♖"
        };
        int selected = -1;

        Board(Activity a) { super(a); p.setTypeface(Typeface.DEFAULT); }

        @Override protected void onDraw(Canvas c) {
            float s = getWidth()/8f;
            for(int r=0;r<8;r++) for(int col=0;col<8;col++) {
                p.setStyle(Paint.Style.FILL);
                p.setColor(((r+col)%2==0) ? Color.rgb(240,217,181) : Color.rgb(181,136,99));
                c.drawRect(col*s,r*s,(col+1)*s,(r+1)*s,p);
                int i=r*8+col;
                if(i==selected) {
                    p.setStyle(Paint.Style.STROKE); p.setStrokeWidth(6); p.setColor(Color.YELLOW);
                    c.drawRect(col*s+3,r*s+3,(col+1)*s-3,(r+1)*s-3,p);
                    p.setStyle(Paint.Style.FILL);
                }
                if(!pieces[i].isEmpty()) {
                    p.setColor(Color.BLACK); p.setTextAlign(Paint.Align.CENTER); p.setTextSize(s*.72f);
                    c.drawText(pieces[i],(col+.5f)*s,(r+.72f)*s,p);
                }
            }
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            if(e.getAction()!=MotionEvent.ACTION_UP) return true;
            float s=getWidth()/8f;
            int col=(int)(e.getX()/s), row=(int)(e.getY()/s);
            if(col<0||col>7||row<0||row>7) return true;
            int sq=row*8+col;
            if(selected<0) {
                if(!pieces[sq].isEmpty()) selected=sq;
            } else {
                pieces[sq]=pieces[selected]; pieces[selected]=""; selected=-1;
            }
            invalidate();
            return true;
        }
    }
}
